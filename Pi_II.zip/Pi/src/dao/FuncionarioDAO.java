package dao;

import java.util.ArrayList;
import java.util.List;

import entity.Dizimista;
import entity.Funcionario;
import util.ArquivoTexto1;

public class FuncionarioDAO {
private ArquivoTexto1 arquivo;
	
	private static final String NOME_ARQUIVO = "funcionarios.txt";
	
	public FuncionarioDAO() {
		this.arquivo = new ArquivoTexto1(NOME_ARQUIVO);
	}
	
	public void inserir(Funcionario funcionario) {
		this.arquivo.inserir(funcionario.toCvs());
	}
	
	public List<Funcionario> listar(){
		List<String> registros = this.arquivo.ler();
		List<Funcionario> funcionarios = new ArrayList<>();
		
		for(String registro : registros) {
			String[] reg = registro.split(";");
			Funcionario funcionario = new Funcionario(reg[0], reg[1], reg[2]);
			funcionarios.add(funcionario);
		}
		return funcionarios;
	}
	
	public void remover(Dizimista dizimista) {
		List<Funcionario> funcionarios = listar();
		for(Funcionario fn : funcionarios) {
			funcionarios.remove(fn);
			break;
		}
		arquivo.apagar();
		for(Funcionario f : funcionarios) {
			this.inserir(f);
		}
	}

}
