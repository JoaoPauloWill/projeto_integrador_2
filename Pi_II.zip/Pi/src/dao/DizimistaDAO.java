package dao;

import java.util.ArrayList;
import java.util.List;

import entity.Dizimista;
import util.ArquivoTexto1;


public class DizimistaDAO {
	
	private ArquivoTexto1 arquivo;
	
	private static final String NOME_ARQUIVO = "dizimistas.txt";
	
	public DizimistaDAO() {
		this.arquivo = new ArquivoTexto1(NOME_ARQUIVO);
	}
	
	
	public void inserir(Dizimista dizimista) {
		this.arquivo.inserir(dizimista.toCvs());
	}
	
	public List<Dizimista> listar(){
		List<String> registros = this.arquivo.ler();
		List<Dizimista> dizimistas = new ArrayList<>();
		
		for(String registro : registros) {
			String[] reg = registro.split(";");
			Dizimista dizimista = new Dizimista(reg[0], reg[1], reg[2], reg[3], Short.parseShort(reg[4]), reg[5]);
			dizimistas.add(dizimista);
		}
		return dizimistas;
	}
	
	public Dizimista pesquisaPeloCpf(String cpf) {
		List<Dizimista> dizimista = listar();
		for (Dizimista dizimista2 : dizimista) {
			if(cpf.equals(dizimista2.getCpf())) {
				return dizimista2;
			}
		}
		return null;
	}
	
	public void remover(Dizimista dizimista) {
		List<Dizimista> dizimistas = listar();
		for(Dizimista dz : dizimistas) {
			dizimistas.remove(dz);
			break;
		}
		arquivo.apagar();
		for(Dizimista d : dizimistas) {
			this.inserir(d);
		}
	}

}
