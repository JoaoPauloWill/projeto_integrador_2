
public class NewClass1 {
}
