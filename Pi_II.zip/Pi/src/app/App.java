package app;

import java.io.IOException;
import form.FuncionarioForm;

public class App {
	public static void main(String[] args) throws IOException {
		//PI JOÃO PAULO
		FuncionarioForm form = new FuncionarioForm();
		form.setVisible(true);
	}
}
