package util;

import javax.swing.text.MaskFormatter;

public class Mascaras {
	
	private static final String MASCARA_TELEFONE = "#####-####";
	private static final String MASCARA_CELULAR = "(##)#####-####";
	private static final String MASCARA_CPF = "###.###.###_##";
	private static final String MASCARA_DATA = "##/##/####";
	private static final String MASCARA_CEP = "##.###-###";
	
	public static MaskFormatter getMascaraTelefone() {
		MaskFormatter maskFormatter = null;
		try {
			maskFormatter = new MaskFormatter(MASCARA_TELEFONE);
		} catch (Exception el) {
			System.out.println("LOG: ocorreu um erro ao criar a máscara do telefone!");
		}
		return maskFormatter;
	}
	
	public static MaskFormatter getMascaraCpf() {
		MaskFormatter maskFormatter = null;
		try {
			maskFormatter = new MaskFormatter(MASCARA_CPF);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um problema ao criar a máscara do cpf!");
		}
		return maskFormatter;
	}
	

}
