package form;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import dao.FuncionarioDAO;
import entity.Funcionario;
import view.MenuSistema;

public class LoginFuncionario extends JFrame {

	private JPanel contentPane;
	private JTextField txtNome;
	private JPasswordField txtSenha;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LoginFuncionario frame = new LoginFuncionario();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private boolean validaLogin() {
		FuncionarioDAO fDAO = new FuncionarioDAO();
		List<Funcionario> funcionarios = fDAO.listar();
		for (Funcionario funcionario : funcionarios) {
			if(txtNome.getText().equals(funcionario.getNome())) {
				if(txtSenha.getText().equals(funcionario.getSenha())) {
					JOptionPane.showMessageDialog(null, "Bem-Vindo(a)!");
					return true;
				}
				else {
					JOptionPane.showMessageDialog(null, "Senha incorreta");
				}
			}
			else {
				JOptionPane.showMessageDialog(null, "Nome incorreto");
			}
		}
		return false;
	}
	
	private boolean validaDados() {
		if(txtNome.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por favor, informe o nome do funcionário");
			return false;
		}
		if(txtNome.getText().trim().length() > 30) {
			JOptionPane.showMessageDialog(null, "O nome do funcionário deve conter no máximo 30 caracteres");
			return false;
		}
		if(txtSenha.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por favor, informe a senha do funcionário");
			return false;
		}
		if(txtSenha.getText().trim().length() < 5) {
			JOptionPane.showMessageDialog(null, "A senha deve conter mais de 5 caracteres");
			return false;
		}
		return true;
	}
	
	public void abreTelaMenu() {
		MenuSistema menu;
		try {
			menu = new MenuSistema();
			menu.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de menu do sistema!");
		}
	}
	
	public void voltaTelaCadastro() {
		FuncionarioForm form;
		try {
			form = new FuncionarioForm();
			form.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de registro do funcionario!");
		}
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public LoginFuncionario() throws IOException {
		
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\senha.png"));
		setTitle("Login Funcionário");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 449);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		txtNome = new JTextField();
		txtNome.setHorizontalAlignment(SwingConstants.CENTER);
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtNome.setBounds(63, 89, 297, 32);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		txtSenha = new JPasswordField();
		txtSenha.setHorizontalAlignment(SwingConstants.CENTER);
		txtSenha.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtSenha.setBounds(63, 228, 297, 32);
		contentPane.add(txtSenha);
		
		JButton btnEntrar = new JButton("Entrar");
		btnEntrar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int aux = 0;
				
				if(!validaDados()) {
					return;
				}
				FuncionarioDAO fDAO = new FuncionarioDAO();
				List<Funcionario> funcionarios = fDAO.listar();
				for (Funcionario funcionario : funcionarios) {
					if(txtNome.getText().equals(funcionario.getNome())) {
						if(txtSenha.getText().equals(funcionario.getSenha())) {
							JOptionPane.showMessageDialog(null, "Bem-Vindo(a)!");
							abreTelaMenu();
							dispose();
						}
						else {
							JOptionPane.showMessageDialog(null, "Senha incorreta");
						}
					}
					else {
						aux = aux + 1;
					}
				}
				
				if(aux == funcionarios.size()) {
					JOptionPane.showMessageDialog(null, "Esse nome não foi encontrado no sistema, por favor se cadastre!");
				}
			}
		});
		btnEntrar.setFont(new Font("Arial Black", Font.PLAIN, 20));
		btnEntrar.setBounds(240, 329, 120, 32);
		contentPane.add(btnEntrar);
		
		JButton btnSair = new JButton("Voltar");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				voltaTelaCadastro();
			}
		});
		btnSair.setFont(new Font("Arial Black", Font.PLAIN, 20));
		btnSair.setBounds(63, 329, 120, 32);
		contentPane.add(btnSair);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblNome.setBounds(63, 46, 297, 32);
		contentPane.add(lblNome);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setBackground(new Color(0, 128, 128));
		lblSenha.setForeground(new Color(0, 0, 0));
		lblSenha.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblSenha.setBounds(63, 185, 297, 32);
		contentPane.add(lblSenha);
		
		BufferedImage bf = ImageIO.read(new File("C:\\Users\\Joaos\\Downloads\\Download Mount Calvary Landscape Vectors for free.png"));
		Image image = bf.getScaledInstance(450, 499, Image.SCALE_DEFAULT);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(image));
		lblNewLabel.setBounds(0, 0, 434, 410);
		contentPane.add(lblNewLabel);
		
		
		
	}
}
