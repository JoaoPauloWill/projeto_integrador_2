package form;

import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dao.FuncionarioDAO;
import entity.Funcionario;
import util.Mascaras;
import javax.swing.SwingConstants;
import java.awt.Color;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.Toolkit;

public class FuncionarioForm extends JFrame {

	private Funcionario funcionario;
	private FuncionarioDAO funcionarioDAO;
	
	private JPanel contentPane;

	private JTextField txtNome;
	private JPasswordField txtSenha;
	private JFormattedTextField formattedTxtTelefone;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FuncionarioForm frame = new FuncionarioForm();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private boolean validaDados() {
		if(txtNome.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por favor, informa o nome do usuário!");
			return false;
		}
		if(txtNome.getText().trim().length() > 30) {
			JOptionPane.showMessageDialog(null, "O nome do usuário deve conter no máximo 30 caracteres");
			return false;
		}
		if(txtSenha.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por favor, informe a senha do usuário!");
			return false;
		}
		if(txtSenha.getText().trim().length() < 5) {
			JOptionPane.showMessageDialog(null, "A senha do usuário deve conter no pelo menos 5 caracteres");
			return false;
		}
		if(formattedTxtTelefone.getText().replace("-", "").trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por favor, informe o número do usuário!");
			return false;
		}
		
		return true;
	}
	
	public void abreTelaLogin() {
		LoginFuncionario form;
		try {
			form = new LoginFuncionario();
			form.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de login de funcionarios!");
		}
	}
	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public FuncionarioForm() throws IOException {
		
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\local-na-rede-internet.png"));
		
		funcionarioDAO = new FuncionarioDAO();
		
		setTitle("Cadastro de funcionário");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 449);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_6 = new JLabel("Lucas 6:38");
		lblNewLabel_6.setForeground(new Color(255, 255, 255));
		lblNewLabel_6.setBackground(new Color(255, 255, 255));
		lblNewLabel_6.setFont(new Font("Arial Black", Font.PLAIN, 16));
		lblNewLabel_6.setBounds(344, 254, 329, 28);
		contentPane.add(lblNewLabel_6);
		
		JLabel lblNewLabel_5 = new JLabel("vocês”.");
		lblNewLabel_5.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_5.setFont(new Font("Arial Black", Font.PLAIN, 16));
		lblNewLabel_5.setBounds(355, 228, 329, 28);
		contentPane.add(lblNewLabel_5);
		
		JLabel lblNewLabel_4 = new JLabel("Pois a medida que usarem ");
		lblNewLabel_4.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_4.setFont(new Font("Arial Black", Font.PLAIN, 16));
		lblNewLabel_4.setBounds(355, 179, 318, 28);
		contentPane.add(lblNewLabel_4);
		
		JLabel lblNewLabel_3 = new JLabel("uma boa medida, calcada, sacudida");
		lblNewLabel_3.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_3.setFont(new Font("Arial Black", Font.PLAIN, 16));
		lblNewLabel_3.setBounds(355, 128, 318, 28);
		contentPane.add(lblNewLabel_3);
		
		JLabel lblNewLabel_2 = new JLabel("também será usada para medir ");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Arial Black", Font.PLAIN, 16));
		lblNewLabel_2.setBounds(355, 201, 318, 32);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel_1 = new JLabel(" e transbordante será dada a vocês. ");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial Black", Font.PLAIN, 16));
		lblNewLabel_1.setBounds(344, 155, 329, 28);
		contentPane.add(lblNewLabel_1);
		
		JLabel lblNewLabel = new JLabel("\"Deem e será dado a vocês: \r\n\r\n");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 16));
		lblNewLabel.setBounds(355, 106, 318, 23);
		contentPane.add(lblNewLabel);
		
		txtNome = new JTextField();
		txtNome.setHorizontalAlignment(SwingConstants.CENTER);
		txtNome.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtNome.setBounds(10, 54, 283, 32);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		JButton btnSair = new JButton("Sair");
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnSair.setFont(new Font("Arial Black", Font.PLAIN, 20));
		btnSair.setBounds(449, 355, 120, 32);
		contentPane.add(btnSair);
		
		formattedTxtTelefone = new JFormattedTextField(Mascaras.getMascaraTelefone());
		formattedTxtTelefone.setHorizontalAlignment(SwingConstants.CENTER);
		formattedTxtTelefone.setFont(new Font("Dialog", Font.PLAIN, 20));
		formattedTxtTelefone.setBounds(10, 256, 283, 32);
		contentPane.add(formattedTxtTelefone);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!validaDados()) {
					return;
				}
				
				funcionario = new Funcionario(
					txtNome.getText(),
					txtSenha.getText(),
					formattedTxtTelefone.getText()
					);
				
				funcionarioDAO.inserir(funcionario);
				
				txtNome.setText("");
				txtSenha.setText("");
				formattedTxtTelefone.setText("");
				
				JOptionPane.showMessageDialog(null, "Cadastro concluído com sucesso!");
			}
		});
		btnSalvar.setFont(new Font("Arial Black", Font.PLAIN, 20));
		btnSalvar.setBounds(86, 355, 120, 32);
		contentPane.add(btnSalvar);
		
		txtSenha = new JPasswordField();
		txtSenha.setHorizontalAlignment(SwingConstants.CENTER);
		txtSenha.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtSenha.setBounds(10, 155, 283, 32);
		contentPane.add(txtSenha);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setHorizontalAlignment(SwingConstants.CENTER);
		lblNome.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblNome.setBounds(10, 11, 283, 32);
		contentPane.add(lblNome);
		
		JLabel lblSenha = new JLabel("Senha");
		lblSenha.setHorizontalAlignment(SwingConstants.CENTER);
		lblSenha.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblSenha.setBounds(10, 112, 283, 32);
		contentPane.add(lblSenha);
		
		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setHorizontalAlignment(SwingConstants.CENTER);
		lblTelefone.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblTelefone.setBounds(10, 213, 283, 32);
		contentPane.add(lblTelefone);
		
		JLabel lblTxtCadastro = new JLabel("Já tem uma conta?");
		lblTxtCadastro.setForeground(new Color(255, 255, 255));
		lblTxtCadastro.setHorizontalAlignment(SwingConstants.RIGHT);
		lblTxtCadastro.setFont(new Font("Arial Black", Font.PLAIN, 15));
		lblTxtCadastro.setBounds(10, 299, 187, 28);
		contentPane.add(lblTxtCadastro);
		
		JLabel lblEntrar = new JLabel("Entrar");
		lblEntrar.setForeground(new Color(255, 255, 0));
		lblEntrar.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				dispose();
				abreTelaLogin();
				
			}
		});
		lblEntrar.setFont(new Font("Arial Black", Font.BOLD | Font.ITALIC, 15));
		lblEntrar.setBounds(207, 299, 86, 28);
		contentPane.add(lblEntrar);
		
		BufferedImage bf = ImageIO.read(new File("C:\\Users\\Joaos\\Downloads\\Illustrations - Glo Bible App.jfif"));
		Image image = bf.getScaledInstance(699, 499, Image.SCALE_DEFAULT);
		
		JLabel lblFundo = new JLabel("New label");
		lblFundo.setIcon(new ImageIcon(image));
		lblFundo.setBounds(0, 0, 683, 410);
		contentPane.add(lblFundo);
	}
}
