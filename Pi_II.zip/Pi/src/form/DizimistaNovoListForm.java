package form;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import dao.DizimistaDAO;
import entity.Dizimista;
import util.Mascaras;
import view.DizimistaList;

public class DizimistaNovoListForm extends JFrame {

	private Dizimista dizimista;
	private DizimistaDAO dizimistaDAO;
	
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtRua;
	private JTextField txtNumero;
	private JTextField txtBairro;
	private JFormattedTextField ftfCpf;
	private JFormattedTextField ftfTelefone;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DizimistaNovoListForm frame = new DizimistaNovoListForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private boolean ValidaDados() {
		if(txtNome.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o nome do dizimista");
			return false;
		}
		if(txtRua.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o logradouro");
			return false;
		}
		if(txtRua.getText().trim().length() > 40) {
			JOptionPane.showMessageDialog(null, "O logradouro conter no máximo 40 caracteres");
			return false;
		}
		if(txtBairro.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o bairro");
			return false;
		}
		if(txtNome.getText().trim().length() > 15) {
			JOptionPane.showMessageDialog(null, "O bairro deve conter no máximo 15 caracteres");
			return false;
		}
		if(txtNumero.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o número da residencia");
			return false;
		}
		if(txtNumero.getText().trim().length() > 4) {
			JOptionPane.showMessageDialog(null, "Número invalido");
			return false;
		}
		if(txtNome.getText().trim().length() > 30) {
			JOptionPane.showMessageDialog(null, "O nome do dizimista deve conter no máximo 30 caracteres");
			return false;
		}
		if(ftfCpf.getText().replace(".", "").trim().equals("_")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o CPF!");
			return false;
		}
		
		dizimistaDAO = new DizimistaDAO();
		List<Dizimista> dizimista = dizimistaDAO.listar();
		for (Dizimista dizimista2 : dizimista) {
			if(ftfCpf.getText().trim().equals(dizimista2.getCpf())) {
				JOptionPane.showMessageDialog(null, "Cpf já cadastrado!");
				return false;
			}
		}
		
		return true;
	}
	
	private void exibeDados() {
		if(this.dizimista != null) {
			txtNome.setText(dizimista.getNome());
			ftfCpf.setText(dizimista.getCpf());
			txtRua.setText(dizimista.getLogradouro());
			txtNumero.setText(String.valueOf(dizimista.getNumeroEndereco()));
			txtBairro.setText(dizimista.getBairro());
			ftfTelefone.setText(String.valueOf(dizimista.getTelefone()));
		}
	}
	
	public void setDizimista(Dizimista dizimista) {
		this.dizimista = dizimista;
		exibeDados();
	}
	
	private void abreTelaCadastro() {
		DizimistaList form;
		try {
			form = new DizimistaList();
			form.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de cadastro do dizimista");
		}
	}
	
	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public DizimistaNovoListForm() throws IOException {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\local-na-rede-internet.png"));
		setTitle("Cadastro de Dizimista");
		dizimistaDAO = new DizimistaDAO();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 699, 449);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel_2 = new JLabel("Opcional");
		lblNewLabel_2.setForeground(new Color(255, 255, 255));
		lblNewLabel_2.setFont(new Font("Dialog", Font.PLAIN, 20));
		lblNewLabel_2.setBounds(20, 289, 103, 26);
		contentPane.add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblNewLabel.setBounds(20, 11, 283, 32);
		contentPane.add(lblNewLabel);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setHorizontalAlignment(SwingConstants.CENTER);
		lblCpf.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblCpf.setBounds(20, 113, 283, 32);
		contentPane.add(lblCpf);
		
		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setHorizontalAlignment(SwingConstants.CENTER);
		lblTelefone.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblTelefone.setBounds(20, 217, 283, 32);
		contentPane.add(lblTelefone);
		
		JLabel lblLogradouro = new JLabel("Logradouro");
		lblLogradouro.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogradouro.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblLogradouro.setBounds(374, 11, 283, 32);
		contentPane.add(lblLogradouro);
		
		JLabel lblNmero = new JLabel("Número");
		lblNmero.setHorizontalAlignment(SwingConstants.CENTER);
		lblNmero.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblNmero.setBounds(374, 113, 283, 32);
		contentPane.add(lblNmero);
		
		JLabel lblBairro = new JLabel("Bairro");
		lblBairro.setHorizontalAlignment(SwingConstants.CENTER);
		lblBairro.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblBairro.setBounds(374, 217, 283, 32);
		contentPane.add(lblBairro);
		
		txtNome = new JTextField();
		txtNome.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtNome.setHorizontalAlignment(SwingConstants.CENTER);
		txtNome.setBounds(20, 49, 283, 34);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		 ftfCpf = new JFormattedTextField(Mascaras.getMascaraCpf());
		 ftfCpf.setHorizontalAlignment(SwingConstants.CENTER);
		 ftfCpf.setFont(new Font("Dialog", Font.PLAIN, 20));
		ftfCpf.setBounds(20, 154, 283, 32);
		contentPane.add(ftfCpf);
		
		 ftfTelefone = new JFormattedTextField(Mascaras.getMascaraTelefone());
		 ftfTelefone.setHorizontalAlignment(SwingConstants.CENTER);
		 ftfTelefone.setFont(new Font("Dialog", Font.PLAIN, 20));
		ftfTelefone.setBounds(20, 258, 283, 32);
		contentPane.add(ftfTelefone);
		
		txtRua = new JTextField();
		txtRua.setHorizontalAlignment(SwingConstants.CENTER);
		txtRua.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtRua.setColumns(10);
		txtRua.setBounds(374, 49, 283, 32);
		contentPane.add(txtRua);
		
		txtNumero = new JTextField();
		txtNumero.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtNumero.setBounds(374, 154, 283, 32);
		contentPane.add(txtNumero);
		txtNumero.setColumns(10);
		
		txtBairro = new JTextField();
		txtBairro.setHorizontalAlignment(SwingConstants.CENTER);
		txtBairro.setFont(new Font("Dialog", Font.PLAIN, 20));
		txtBairro.setColumns(10);
		txtBairro.setBounds(374, 258, 283, 32);
		contentPane.add(txtBairro);
		
		JButton btnNewButton = new JButton("Cadastrar");
		btnNewButton.setFont(new Font("Arial Black", Font.BOLD, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				if(!ValidaDados()) {
					return;
				}
				
				try {
					dizimista= new Dizimista(
							txtNome.getText(), 
							ftfCpf.getText(), 
							ftfTelefone.getText(), 
							txtRua.getText(),
							Short.parseShort(txtNumero.getText()), 
							txtBairro.getText()
							);
					
					dizimistaDAO.inserir(dizimista);
					
					JOptionPane.showMessageDialog(null, "Cadastro realizado com sucesso!");
					txtNome.setText("");
					ftfCpf.setText("");
					ftfTelefone.setText("");
					txtRua.setText("");
					txtNumero.setText("");
					txtBairro.setText("");
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Caracter do número inválido!");
				}
			}
		});
		btnNewButton.setBounds(84, 366, 151, 32);
		contentPane.add(btnNewButton);
		
		JButton btnSair = new JButton("Voltar");
		btnSair.setFont(new Font("Arial Black", Font.BOLD, 20));
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				
			}
		});
		btnSair.setBounds(464, 366, 120, 32);
		contentPane.add(btnSair);
		
		BufferedImage bf = ImageIO.read(new File("C:\\Users\\Joaos\\Downloads\\Download Holy Week Day Free Vector for free.jfif"));
		Image image = bf.getScaledInstance(699, 499, Image.SCALE_DEFAULT);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(image));
		lblNewLabel_1.setBounds(0, 0, 683, 417);
		contentPane.add(lblNewLabel_1);
	}


}
