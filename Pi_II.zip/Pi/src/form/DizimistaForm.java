package form;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import dao.DizimistaDAO;
import entity.Dizimista;
import util.Mascaras;
import view.DizimistaList;
import java.awt.Font;
import javax.swing.SwingConstants;
import java.awt.Color;
import java.awt.Toolkit;

public class DizimistaForm extends JFrame {

	private Dizimista dizimista;
	private DizimistaDAO dizimistaDAO;
	
	private JPanel contentPane;
	private JTextField txtNome;
	private JTextField txtRua;
	private JTextField txtNumero;
	private JTextField txtBairro;
	private JFormattedTextField ftfCpf;
	private JFormattedTextField ftfTelefone;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DizimistaForm frame = new DizimistaForm();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private boolean ValidaDados() {
		if(txtNome.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o nome do dizimista");
			return false;
		}
		if(txtRua.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o logradouro");
			return false;
		}
		if(txtRua.getText().trim().length() > 40) {
			JOptionPane.showMessageDialog(null, "O logradouro conter no máximo 40 caracteres");
			return false;
		}
		if(txtBairro.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o bairro");
			return false;
		}
		if(txtBairro.getText().trim().length() > 25) {
			JOptionPane.showMessageDialog(null, "O bairro deve conter no máximo 15 caracteres");
			return false;
		}
		if(txtNumero.getText().trim().equals("")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o número da residencia");
			return false;
		}
		if(txtNumero.getText().trim().length() > 4) {
			JOptionPane.showMessageDialog(null, "Número invalido");
			return false;
		}
		if(txtNome.getText().trim().length() > 30) {
			JOptionPane.showMessageDialog(null, "O nome do dizimista deve conter no máximo 30 caracteres");
			return false;
		}
		if(ftfCpf.getText().replace(".", "").trim().equals("_")) {
			JOptionPane.showMessageDialog(null, "Por Favor, informe o CPF!");
			return false;
		}
		
		return true;
	}
	
	private void exibeDados() {
		if(this.dizimista != null) {
			txtNome.setText(dizimista.getNome());
			ftfCpf.setText(dizimista.getCpf());
			txtRua.setText(dizimista.getLogradouro());
			txtNumero.setText(String.valueOf(dizimista.getNumeroEndereco()));
			txtBairro.setText(dizimista.getBairro());
			ftfTelefone.setText(String.valueOf(dizimista.getTelefone()));
		}
	}
	
	public void setDizimista(Dizimista dizimista) {
		this.dizimista = dizimista;
		exibeDados();
	}
	
	private void abreTelaCadastro() {
		DizimistaList form;
		try {
			form = new DizimistaList();
			form.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de cadastro do dizimista");
		}
	}
	/**
	 * Create the frame.
	 */
	public DizimistaForm() {
		setTitle("Cadastro Dizimista");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\local-na-rede-internet.png"));
		
		dizimistaDAO = new DizimistaDAO();
		
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 679, 456);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNewLabel.setBounds(20, 11, 245, 27);
		contentPane.add(lblNewLabel);
		
		JLabel lblCpf = new JLabel("CPF");
		lblCpf.setHorizontalAlignment(SwingConstants.CENTER);
		lblCpf.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblCpf.setBounds(20, 116, 245, 27);
		contentPane.add(lblCpf);
		
		JLabel lblTelefone = new JLabel("Telefone");
		lblTelefone.setHorizontalAlignment(SwingConstants.CENTER);
		lblTelefone.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblTelefone.setBounds(10, 220, 255, 27);
		contentPane.add(lblTelefone);
		
		JLabel lblLogradouro = new JLabel("Logradouro");
		lblLogradouro.setHorizontalAlignment(SwingConstants.CENTER);
		lblLogradouro.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblLogradouro.setBounds(374, 11, 245, 27);
		contentPane.add(lblLogradouro);
		
		JLabel lblNmero = new JLabel("Número");
		lblNmero.setHorizontalAlignment(SwingConstants.CENTER);
		lblNmero.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblNmero.setBounds(374, 116, 245, 27);
		contentPane.add(lblNmero);
		
		JLabel lblBairro = new JLabel("Bairro");
		lblBairro.setHorizontalAlignment(SwingConstants.CENTER);
		lblBairro.setFont(new Font("Tahoma", Font.PLAIN, 19));
		lblBairro.setBounds(374, 220, 245, 27);
		contentPane.add(lblBairro);
		
		txtNome = new JTextField();
		txtNome.setHorizontalAlignment(SwingConstants.CENTER);
		txtNome.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNome.setBounds(20, 49, 245, 34);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		 ftfCpf = new JFormattedTextField(Mascaras.getMascaraCpf());
		 ftfCpf.setHorizontalAlignment(SwingConstants.CENTER);
		 ftfCpf.setFont(new Font("Tahoma", Font.PLAIN, 15));
		ftfCpf.setBounds(20, 154, 245, 34);
		contentPane.add(ftfCpf);
		
		 ftfTelefone = new JFormattedTextField(Mascaras.getMascaraTelefone());
		 ftfTelefone.setHorizontalAlignment(SwingConstants.CENTER);
		 ftfTelefone.setFont(new Font("Tahoma", Font.PLAIN, 15));
		ftfTelefone.setBounds(20, 258, 245, 34);
		contentPane.add(ftfTelefone);
		
		txtRua = new JTextField();
		txtRua.setHorizontalAlignment(SwingConstants.CENTER);
		txtRua.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtRua.setColumns(10);
		txtRua.setBounds(374, 49, 245, 34);
		contentPane.add(txtRua);
		
		txtNumero = new JTextField();
		txtNumero.setHorizontalAlignment(SwingConstants.CENTER);
		txtNumero.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtNumero.setBounds(374, 154, 245, 34);
		contentPane.add(txtNumero);
		txtNumero.setColumns(10);
		
		txtBairro = new JTextField();
		txtBairro.setHorizontalAlignment(SwingConstants.CENTER);
		txtBairro.setFont(new Font("Tahoma", Font.PLAIN, 15));
		txtBairro.setColumns(10);
		txtBairro.setBounds(374, 258, 245, 34);
		contentPane.add(txtBairro);
		
		JButton btnNewButton = new JButton("Cadastrar");
		btnNewButton.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(!ValidaDados()) {
					return;
				}
				try {
					dizimista= new Dizimista(
							txtNome.getText(), 
							ftfCpf.getText(), 
							ftfTelefone.getText(), 
							txtRua.getText(),
							Short.parseShort(txtNumero.getText()), 
							txtBairro.getText()
							);
					

					dizimistaDAO.inserir(dizimista);
					
					txtNome.setText("");
					ftfCpf.setText("");
					ftfTelefone.setText("");
					txtRua.setText("");
					txtNumero.setText("");
					txtBairro.setText("");
					
					JOptionPane.showMessageDialog(null, "Os dados foram salvos com sucesso!");
					
					abreTelaCadastro();
					dispose();
					
				} catch (Exception e2) {
					JOptionPane.showMessageDialog(null, "Caracter do número inválido!");
				}
			}
		});
		btnNewButton.setBounds(374, 366, 125, 40);
		contentPane.add(btnNewButton);
		
		JButton btnSair = new JButton("Sair");
		btnSair.setFont(new Font("Tahoma", Font.PLAIN, 20));
		btnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
				
				abreTelaCadastro();
			}
		});
		btnSair.setBounds(144, 366, 111, 40);
		contentPane.add(btnSair);
		
		JLabel lblNewLabel_1 = new JLabel("(Opcional)");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(20, 242, 68, 14);
		contentPane.add(lblNewLabel_1);
	}

}
