package TableModel;

import java.util.List;

import javax.swing.table.AbstractTableModel;

import entity.Dizimista;

public class DizimistaTableModelNome extends AbstractTableModel{
	private static final long serialVersionUID = 1L;
	
	private static final String[] colunas = {"Nome"};
	private static final Class[] coluna_classes = {String.class};
	private List<Dizimista> dizimistas;
	
	private final int COLUNA_NOME = 0;
	
	public DizimistaTableModelNome(List<Dizimista> dizimistas) {
		super();
		this.dizimistas = dizimistas;
	}
	
	

	//remove todos os iten da tabela
	public void removeAllItens() {
		dizimistas.clear();
	}
	
	public void addItem(Dizimista dizimista) {
		dizimistas.add(dizimista);
	}
	
	public void removeItem(Dizimista dizimista) {
		dizimistas.remove(dizimista);
	}
	//adiciona um item na tabela
	public void itemAdd(Dizimista dizimista) {
		dizimistas.add(dizimista);
	}
	
	@Override
	public boolean isCellEditable(int rowIndex, int columnIndex) {
		return false;
	}
	
	@Override
    public Class<?> getColumnClass(int columnIndex) {
        return coluna_classes[columnIndex];
    }
	
	//obtem o titulo da coluna
	public String getColumnName(int column) {
		return colunas[column];
	}
	
	//retorna a quantidade de registros na tabela
	@Override
	public int getRowCount() {
		return dizimistas.size();
	}
	@Override
	public int getColumnCount() {
		return colunas.length;
	}
	
	@Override
	public Object getValueAt(int rowINdex, int columnIndex) {
		Dizimista dizimista = dizimistas.get(rowINdex);
		
		switch(columnIndex) {
			case COLUNA_NOME:
				return dizimista.getNome();
			default:
				return null;
		}
	}
}
