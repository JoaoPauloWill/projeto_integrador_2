package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import TableModel.DizimistaTableModel;
import dao.DizimistaDAO;
import entity.Dizimista;
import form.DizimistaForm;


public class DizimistaList extends JFrame {

	private JPanel contentPane;
	private DizimistaTableModel dizimistaTableModel;
	private DizimistaDAO dao;
	private List<Dizimista> dizimistas;
	private JScrollPane scrollPane_1;
	private JTable tbDados;
	private JButton BtnSair;
	private JTextArea textArea;
	private JTextField txtFiltro;
	private JButton btnFiltro;
	private JButton btnRemover;
	private JLabel lblNewLabel;
	private JLabel lblNewLabel_1;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					DizimistaList frame = new DizimistaList();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Dizimista getDizimistaSelecionado() {
		int linha = tbDados.getSelectedRow();
		String nome = tbDados.getValueAt(linha, 0).toString();
		for(Dizimista dizimista : dizimistas) {
			if(dizimista.getNome().equals(nome)) {
				return dizimista;
			}
		}
		return null;
	}
	
	public void consultaDizimistas() {
		dizimistas = dao.listar();
		dizimistaTableModel.removeAllItens();
		if (txtFiltro.getText().length() > 0) {
			for (Dizimista dizimista : dizimistas) {
				int filtroComprimento = txtFiltro.getText().length();
				int categoriaComprimento = dizimista.getNome().length();
				if (filtroComprimento <= categoriaComprimento) {
					if (dizimista.getNome().substring(0, txtFiltro.getText().length()).equals(txtFiltro.getText()) ) {
						dizimistaTableModel.addItem(dizimista);
					}
				}
			}
		} else {
			for (Dizimista dizimista : dizimistas) {
				dizimistaTableModel.addItem(dizimista);
			}			
		}
		// atualiza os registros da tabela
		dizimistaTableModel.fireTableDataChanged();
	}
	
	public void cadastraCategoria() {
		DizimistaForm form = new DizimistaForm();
		form.setDizimista(null);
		form.setVisible(true);
	}
	
	public void editaDizimista() {
		Dizimista dizimista = getDizimistaSelecionado();
		if(dizimista != null) {
			DizimistaForm form = new DizimistaForm();
			form.setDizimista(dizimista);
			form.setVisible(true);
		}
	}
	
	

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public DizimistaList() throws IOException {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\lista-de-desejos.png"));
		setTitle("Lista de Dizimistas");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 449);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane_1 = new JScrollPane();
		scrollPane_1.setBounds(356, 38, 320, 326);
		contentPane.add(scrollPane_1);
		
		dao = new DizimistaDAO();
		dizimistas = dao.listar();
		
		dizimistaTableModel = new DizimistaTableModel(dizimistas);
		tbDados = new JTable(dizimistaTableModel);
		tbDados.setFont(new Font("Dialog", Font.PLAIN, 16));
		scrollPane_1.setViewportView(tbDados);
		
		BtnSair = new JButton("Voltar");
		BtnSair.setFont(new Font("Tahoma", Font.BOLD, 15));
		BtnSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		BtnSair.setBounds(571, 375, 105, 23);
		contentPane.add(BtnSair);
		
		textArea = new JTextArea();
		textArea.setFont(new Font("Arial Black", Font.PLAIN, 18));
		textArea.setBounds(10, 77, 336, 241);
		contentPane.add(textArea);
		
		txtFiltro = new JTextField();
		txtFiltro.setBounds(10, 38, 254, 28);
		contentPane.add(txtFiltro);
		txtFiltro.setColumns(10);
		
		btnRemover = new JButton("Apagar");
		btnRemover.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnRemover.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				for (Dizimista dizimista : dizimistas) {
					if(dizimista.getCpf().equals(getDizimistaSelecionado().getCpf())) {
						System.out.println(dizimista.getNome() + getDizimistaSelecionado().getNome());
						dao.remover(dizimista);
					}
				}
				JOptionPane.showMessageDialog(null, "Dizimista apagado com sucesso!");
				textArea.setText("");
				consultaDizimistas();
			}
		});
		btnRemover.setVisible(false);
		btnRemover.setBounds(121, 329, 105, 35);
		contentPane.add(btnRemover);
		
		btnFiltro = new JButton("Buscar");
		btnFiltro.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnFiltro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				consultaDizimistas();
			}
		});
		btnFiltro.setBounds(268, 38, 80, 28);
		contentPane.add(btnFiltro);
		
		lblNewLabel = new JLabel("Busca pelo nome");
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Arial Black", Font.PLAIN, 20));
		lblNewLabel.setBounds(10, 11, 186, 23);
		contentPane.add(lblNewLabel);
		
		
		BufferedImage bf = ImageIO.read(new File("C:\\Users\\Joaos\\Downloads\\Download Mount Calvary Landscape Vectors for free.png"));
		Image image = bf.getScaledInstance(699, 499, Image.SCALE_DEFAULT);
		
		lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(image));
		lblNewLabel_1.setBounds(0, 0, 686, 410);
		contentPane.add(lblNewLabel_1);
	
		tbDados.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1) {
					btnRemover.setVisible(true);
					textArea.setText("");
					textArea.append("DADOS DO DIZIMISTA\n" + "Nome: " + getDizimistaSelecionado().getNome() + "\nCPF: " + getDizimistaSelecionado().getCpf() + "\nTelefone: " + getDizimistaSelecionado().getTelefone() + "\nRua: " + getDizimistaSelecionado().getLogradouro() + "\nNúmero: " + getDizimistaSelecionado().getNumeroEndereco() + "\nBairro: " + getDizimistaSelecionado().getBairro());
				
				}
			}
		});
	}
}
