package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.TextArea;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;

import form.DizimistaNovoListForm;
import javax.swing.UIManager;
import java.awt.SystemColor;

public class MenuSistema extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MenuSistema frame = new MenuSistema();
					frame.setLocationRelativeTo(null);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public void abreCadastroDizimista() {
		DizimistaNovoListForm FomrDizimista;
		try {
			FomrDizimista = new DizimistaNovoListForm();
			FomrDizimista.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de cadastro do dizimista!");
		}
	}
	
	public void abreCadastroFuncionario() {
		CadastroFuncionario formF;
		try {
			formF = new CadastroFuncionario();
			formF.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de cadastro do funcionário!");
		}
	}
	
	public void abreListaDizimista() {
		DizimistaList formLista;
		try {
			formLista = new DizimistaList();
			formLista.setVisible(true);
		} catch(Exception e) {
			System.out.println("LOG: ocorreu um erro ao abrir a tela de lista de dizimistas!");
		}
	}
	
	public void abreTelaOferta() {
		Oferta formOferta;
		PopUp formAviso;
		try {
			formOferta = new Oferta();
			formAviso = new PopUp();
			formOferta.setVisible(true);
			formAviso.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocooreu um erro ao abrir a tela de oferta!");
		}
	}
	
	public void abreTelaConsulta() {
		ConsultaDizimos formConsulta;
		try {
			formConsulta = new ConsultaDizimos();
			formConsulta.setVisible(true);
		} catch (Exception e) {
			System.out.println("LOG: ocooreu um problema ao abrir a tela de consulta de dizimos!");
		}
	}
	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public MenuSistema() throws IOException {
		setTitle("Menu");
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\igreja.png"));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 449);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setForeground(new Color(0, 0, 255));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		BufferedImage bf = ImageIO.read(new File("C:\\Users\\Joaos\\Downloads\\Download Mount Calvary Landscape Vectors for free.png"));
		Image image = bf.getScaledInstance(699, 449, Image.SCALE_DEFAULT);
		
		JButton btnNewButton_2_2 = new JButton("Consultar dizimos ");
		btnNewButton_2_2.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton_2_2.setForeground(Color.BLACK);
		btnNewButton_2_2.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_2_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				abreTelaConsulta();
			}
		});
		
		JButton btnNewButton_2_1 = new JButton("Lista de Dizimistas");
		btnNewButton_2_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton_2_1.setForeground(Color.BLACK);
		btnNewButton_2_1.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_2_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				abreListaDizimista();
			}
		});
		
		JButton btnNewButton_2 = new JButton("Realizar uma oferta");
		btnNewButton_2.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton_2.setForeground(Color.BLACK);
		btnNewButton_2.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				abreTelaOferta();
			}
		});
		
		JButton btnNewButton_1 = new JButton("Cadastrar Dizimista");
		btnNewButton_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton_1.setForeground(Color.BLACK);
		btnNewButton_1.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				abreCadastroDizimista();
			}
		});
		
		JButton btnNewButton = new JButton("Cadastrar Funcionário");
		btnNewButton.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton.setForeground(Color.BLACK);
		btnNewButton.setBackground(UIManager.getColor("Button.background"));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				abreCadastroFuncionario();
			}
		});
		btnNewButton.setBounds(10, 11, 186, 29);
		contentPane.add(btnNewButton);
		btnNewButton_1.setBounds(10, 51, 186, 29);
		contentPane.add(btnNewButton_1);
		btnNewButton_2.setBounds(10, 90, 186, 29);
		contentPane.add(btnNewButton_2);
		
		JPanel panel = new JPanel();
		panel.setBackground(SystemColor.activeCaption);
		panel.setBounds(206, 11, 467, 388);
		contentPane.add(panel);
		panel.setLayout(null);
		
		TextArea textArea = new TextArea();
		textArea.setEditable(false);
		textArea.setBackground(SystemColor.text);
		textArea.setFont(new Font("Arial Black", Font.PLAIN, 18));
		textArea.setBounds(10, 40, 447, 338);
		panel.add(textArea);
		
		
		JButton btnNewButton_3_1 = new JButton("Datas Importantes");
		btnNewButton_3_1.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton_3_1.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_3_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("    DATAS IMPORTANTES DO MÊS DE DEZEMBRO \n"
						+ "\n             Dia:02 – 1ª sexta-feira\r\n"
						+ "             Dia:03 – São Francisco Xavier\r\n"
						+ "\r-----------------------------------------------------------------------------\n"
						+ "             Dia:04 – 2º domingo do Advento\r\n"
						+ "\r-----------------------------------------------------------------------------\n"
						+ "             Dia:06 – São Nicolau\r\n"
						+ "             Dia:07 – Santo Ambrósio\r\n"
						+ "\r------------------------------------------------------------------------------\n"
						+ "             Dia:08 – Imaculada Conceição de Maria\r\n"
						+ "             Dia:09 – São João Diego\r\n"
						+ "             Dia:10 – Bem-aventurada Virgem Maria de Loreto\r\n"
						+ "\r--------------------------------------------------------------------------------\n"
						+ "             Dia:11 – 3º domingo do Advento\r\n"
						+ "\r----------------------------------------------------------------------------------\n"
						+ "             Dia:12 – Nossa Senhora de Guadalupe\r\n"
						+ "             Dia:13 – Santa Luzia\r\n"
						+ "             Dia:14 – São João da Cruz\r\n"
						+ "\r---------------------------------------------------------------------------------\n"
						+ "             Dia:18 – 4º domingo do Advento\r\n"
						+ "\r---------------------------------------------------------------------------------\n"
						+ "             Dia:21 – São Pedro Canísio\r\n"
						+ "             Dia:23 – São João Câncio\r\n"
						+ "\r----------------------------------------------------------------------------------\n"
						+ "             Dia:25 – Natal de Jesus\r\n"
						+ "\r-------------------------------------------------------------------------------------\n"
						+ "             Dia:26 – Santo Estêvão\r\n"
						+ "             Dia:27 – São João Evangelista\r\n"
						+ "             Dia:28 – Santos Inocentes\r\n"
						+ "             Dia:29 – São Tomás Becket\r\n"
						+ "             Dia:30 – Sagrada Família\r\n"
						+ "             Dia:31 – São Silvestre 1ª\r\n"
			);
			}
		});
		btnNewButton_3_1.setBounds(252, 11, 183, 23);
		panel.add(btnNewButton_3_1);
		
		JButton btnNewButton_3 = new JButton("Oração do dia");
		btnNewButton_3.setFont(new Font("Arial Black", Font.PLAIN, 12));
		btnNewButton_3.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea.setText("      ORAÇÃO DE SÃO CARLOS BORROMEU \r\n"
						+ "\r\n"
						+ "\r\n"
						+ "“Ó Deus, que aos vossos pastores associastes "
						+ "\r\nSão Carlos Borromeu, "
						+ "\r\nanimado de ardente caridade e da fé que "
						+ "\r\nvence o mundo, dai-nos, "
						+ "\r\npor sua intercessão, perseverar na caridade e na fé, "
						+ "\r\npara participarmos de sua glória. \r\n"
						+ "Por Nosso Senhor Jesus Cristo, vosso filho,"
						+ "\r\nna unidade do Espírito Santo. \r\n"
						+ "Amém. São Carlos Borromeu, rogai por nós.\r\n"
						+ "");
			}
		});
		btnNewButton_3.setBounds(32, 11, 183, 23);
		panel.add(btnNewButton_3);
		
		JLabel lblImagem = new JLabel("");
		lblImagem.setIcon(new ImageIcon("C:\\Users\\Joaos\\Downloads\\baixados.jfif"));
		lblImagem.setHorizontalAlignment(SwingConstants.CENTER);
		lblImagem.setBounds(10, 200, 186, 199);
		contentPane.add(lblImagem);
		btnNewButton_2_1.setBounds(10, 130, 186, 29);
		contentPane.add(btnNewButton_2_1);
		btnNewButton_2_2.setBounds(10, 170, 186, 29);
		contentPane.add(btnNewButton_2_2);
		
		JLabel lblNewLabel_1 = new JLabel("New label");
		lblNewLabel_1.setIcon(new ImageIcon(image));
		lblNewLabel_1.setBounds(0, 0, 683, 408);
		contentPane.add(lblNewLabel_1);
		
	}
}
