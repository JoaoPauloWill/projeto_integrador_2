package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import TableModel.ConsultaTableModel;
import dao.DizimistaDAO2;
import entity.Dizimista;

public class ConsultaDizimos extends JFrame {

	private JPanel contentPane;
	private List<Dizimista> dizimista;
	private DizimistaDAO2 dao;
	private ConsultaTableModel consultaTableModel;
	private JTable table;
	private JButton btnNewButton;
	private JButton btnNewButton_1;
	private JTextField textField;
	private JLabel lblNewLabel;
	float valor = 0;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ConsultaDizimos frame = new ConsultaDizimos();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public ConsultaDizimos() throws IOException {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\consulta-de-pesquisa.png"));
		setTitle("Consulta de Dizimos");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 449);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setForeground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(37, 43, 607, 280);
		contentPane.add(scrollPane);
		
		dao = new DizimistaDAO2();
		dizimista = dao.listar();
		
		consultaTableModel = new ConsultaTableModel(dizimista);
		table = new JTable(consultaTableModel);
		table.setFont(new Font("Dialog", Font.PLAIN, 16));
		scrollPane.setViewportView(table);
		
		btnNewButton = new JButton("Voltar");
		btnNewButton.setBackground(Color.LIGHT_GRAY);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton.setBounds(527, 358, 117, 27);
		contentPane.add(btnNewButton);
		
		
		textField = new JTextField();
		textField.setFont(new Font("Arial Black", Font.PLAIN, 16));
		textField.setEditable(false);
		textField.setBounds(186, 358, 152, 27);
		contentPane.add(textField);
		textField.setColumns(10);
		
		btnNewButton_1 = new JButton("Valor total ");
		btnNewButton_1.setFont(new Font("Arial Black", Font.PLAIN, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dizimista = dao.listar();
				for (Dizimista dizimista2 : dizimista) {
					valor = valor + Float.parseFloat(dizimista2.getValor());
				}
				textField.setText("R$" + valor);
			}
		});
		btnNewButton_1.setBounds(37, 358, 139, 27);
		contentPane.add(btnNewButton_1);
		
		BufferedImage bf = ImageIO.read(new File("C:\\Users\\Joaos\\Downloads\\Download Mount Calvary Landscape Vectors for free.png"));
		Image image = bf.getScaledInstance(699, 499, Image.SCALE_DEFAULT);
		
		lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(image));
		lblNewLabel.setBounds(0, 0, 683, 410);
		contentPane.add(lblNewLabel);
		
		
	}

}
