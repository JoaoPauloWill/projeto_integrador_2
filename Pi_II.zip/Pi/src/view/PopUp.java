package view;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextPane;
import java.awt.TextArea;
import java.awt.TextField;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import java.awt.Font;
import java.awt.Toolkit;
import java.awt.Color;
import javax.swing.UIManager;

public class PopUp extends JFrame {

	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PopUp frame = new PopUp();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PopUp() {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\solucao.png"));
		setTitle("ATENÇÃO");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 282, 290);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTextPane txtpnParaRealizarUma = new JTextPane();
		txtpnParaRealizarUma.setBackground(UIManager.getColor("Button.highlight"));
		txtpnParaRealizarUma.setEditable(false);
		txtpnParaRealizarUma.setFont(new Font("Tahoma", Font.PLAIN, 20));
		txtpnParaRealizarUma.setText("Para realizar uma oferta, \r\nprimeiramente escolha\r\no valor da oferta, e\r\npara finaliza-la escolha o \r\nnome do dizimista que ira fazer a oferta.");
		txtpnParaRealizarUma.setBounds(10, 11, 246, 229);
		contentPane.add(txtpnParaRealizarUma);
	}
}
