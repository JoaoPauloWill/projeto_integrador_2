package view;

import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.List;

import javax.imageio.ImageIO;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;

import TableModel.DizimistaTableModelNome;
import dao.DizimistaDAO;
import dao.DizimistaDAO2;
import entity.Dizimista;

public class Oferta extends JFrame {

	private JPanel contentPane;
	private JTable tbDados;
	private DizimistaTableModelNome dizimistaTableModelNome;
	private DizimistaDAO dao1;
	private DizimistaDAO2 dao;
	private List<Dizimista> dizimistas;
	private JComboBox comboBox;
	private Dizimista dizimista;
	private JLabel lblNewLabel_1;
	private JButton btnNewButton_1;
	private JLabel lblNewLabel_3;
	private LocalDate localDate;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Oferta frame = new Oferta();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	public Dizimista getDizimistaSelecionado() {
		int linha = tbDados.getSelectedRow();
		String nome = tbDados.getValueAt(linha, 0).toString();
		for(Dizimista dizimista : dizimistas) {
			if(dizimista.getNome().equals(nome)) {
				return dizimista;
			}
		}
		return null;
	}
	


	/**
	 * Create the frame.
	 * @throws IOException 
	 */
	public Oferta() throws IOException {
		setIconImage(Toolkit.getDefaultToolkit().getImage("C:\\Users\\Joaos\\Downloads\\dizimo.png"));
		setTitle("Oferta");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 699, 449);
		contentPane = new JPanel();
		contentPane.setBackground(new Color(0, 128, 128));
		contentPane.setForeground(new Color(0, 128, 128));
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(323, 47, 319, 334);
		contentPane.add(scrollPane);
		
		dao = new DizimistaDAO2();
		dao1 = new DizimistaDAO();
		dizimistas = dao1.listar();
		
		dizimistaTableModelNome = new DizimistaTableModelNome(dizimistas);
		tbDados = new JTable(dizimistaTableModelNome);
		tbDados.setFont(new Font("Dialog", Font.PLAIN, 16));
		scrollPane.setViewportView(tbDados);
		
		comboBox = new JComboBox();
		comboBox.setBackground(UIManager.getColor("Button.background"));
		comboBox.setFont(new Font("Tahoma", Font.PLAIN, 20));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"5", "10", "15", "20", "25", "30", "35", "40", "45", "50", "55", "60", "65", "70", "75", "80", "85", "90", "95", "100"}));
		comboBox.setBounds(87, 104, 140, 35);
		contentPane.add(comboBox);
		
		lblNewLabel_1 = new JLabel("Valor da oferta");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Arial Black", Font.BOLD, 20));
		lblNewLabel_1.setBounds(10, 45, 303, 25);
		contentPane.add(lblNewLabel_1);
		
		btnNewButton_1 = new JButton("Voltar");
		btnNewButton_1.setBackground(UIManager.getColor("Button.background"));
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnNewButton_1.setBounds(93, 339, 120, 39);
		contentPane.add(btnNewButton_1);
		
		BufferedImage bf = ImageIO.read(new File("C:\\Users\\Joaos\\Downloads\\Download Mount Calvary Landscape Vectors for free.png"));
		Image image = bf.getScaledInstance(699, 499, Image.SCALE_DEFAULT);
		
		lblNewLabel_3 = new JLabel("New label");
		lblNewLabel_3.setIcon(new ImageIcon(image));
		lblNewLabel_3.setBounds(0, 0, 683, 410);
		contentPane.add(lblNewLabel_3);
		
		tbDados.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				if (e.getClickCount() == 1) {
					List<Dizimista> dizi = dao1.listar();
					for (Dizimista dizimista : dizi) {
						if(dizimista.getNome().equals(getDizimistaSelecionado().getNome())) {
							dizimista = new Dizimista(getDizimistaSelecionado().getNome(), comboBox.getSelectedItem().toString());
							dao.inserir(dizimista);
						}
					}
					JOptionPane.showMessageDialog(null, "Oferta de R$" + comboBox.getSelectedItem().toString() + " no nome de " + getDizimistaSelecionado().getNome()+ " realizada com sucesso!!");
				}
			}
		});
		
		
		
		
	}

}
