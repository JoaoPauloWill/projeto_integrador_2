package entity;

public class Funcionario {
	private String nome;
	private String senha;
	private String telefone;
	
	public Funcionario(String nome, String senha, String telefone) {
		this.nome = nome;
		this.senha = senha;
		this.telefone = telefone;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}
	
	public String getTelefone() {
		return telefone;
	}
	
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String toCvs() {
		return this.nome + ";" + this.senha + ";" + this.telefone;
	
	}
}
