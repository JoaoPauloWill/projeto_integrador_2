package entity;


public class Dizimista {
	
	private String nome;
	private String cpf;
	private String telefone;
	private String logradouro;
	private short numeroEndereco;
	private String bairro;
	private String valor;
	
	public Dizimista(String nome, String valor) {
		this.nome = nome;
		this.valor = valor;
	}
	
	public Dizimista(String nome, String cpf, String telefone, String logradouro, short numeroEndereco, String bairro) {
		this.nome = nome;
		this.cpf = cpf;
		this.telefone = telefone;
		this.logradouro = logradouro;
		this.numeroEndereco = numeroEndereco;
		this.bairro = bairro;
	}
	
	public String getNome() {
		return nome;
	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	public String getCpf() {
		return cpf;
	}
	
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}
	
	public String getTelefone() {
		return telefone;
	}
	
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}
	
	public String getLogradouro() {
		return logradouro;
	}
	
	public void setLogradouro(String logradouro) {
		this.logradouro = logradouro;
	}
	
	public short getNumeroEndereco() {
		return numeroEndereco;
	}
	
	public void setNumeroEndereco(short numeroEndereco) {
		this.numeroEndereco = numeroEndereco;
	}
	
	public String getBairro() {
		return bairro;
	}
	
	public String getValor() {
		return valor;
	}
	
	public void setValor(String valor) {
		this.valor = valor;
	}
	
	public void setBairro(String bairro) {
		this.bairro = bairro;
	}
	

	public String toCvs() {
		return this.nome + ";" + this.cpf + ";" + this.telefone + ";" + this.logradouro + ";" + this.numeroEndereco + ";" + this.bairro + ";" + this.valor;
	
	}
	
	public String toCvs2() {
		return this.nome + ";" + this.valor;
	
	}
}
